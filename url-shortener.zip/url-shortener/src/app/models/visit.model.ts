export interface Visit {
  message: string;
  projectName: string;
  uniqueVisitors: number;
}
